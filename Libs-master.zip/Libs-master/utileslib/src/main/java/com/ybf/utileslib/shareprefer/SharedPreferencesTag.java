package com.ybf.utileslib.shareprefer;

/**
 * 当前类注释:当前类用户SharedPreferences进行save的时候 配置key常量
 */
public class SharedPreferencesTag {
    public static final String DEMO_KEY="demo_key";

}
