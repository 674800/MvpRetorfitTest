package com.ybf.utileslib.receiver;

/**
 * Created by ybf on 2019/1/21.
 */
public interface Action {
    /**
     *Log 打开需要发送广播
     */
    public  String IS_DEBUG = "com.ybf.loginfo";

}
